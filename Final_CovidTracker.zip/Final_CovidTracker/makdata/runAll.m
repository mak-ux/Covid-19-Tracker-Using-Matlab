prn = 'off';
plt = 'on';
try
  fitVirusCV19(@getDataWorld,'prn',prn,'jpg',plt)
end
try
  fitVirusCV19(@getDataIndia,'prn',prn,'jpg',plt)
end
  

